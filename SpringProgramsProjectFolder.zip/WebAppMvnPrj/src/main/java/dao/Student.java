package dao;

public class Student {
	int StudentNo;
	String StudentName;
	String StudentDept;

	public int getStudentNo() {
		return StudentNo;
	}
	public void setStudentNo(int studentNo) {
		StudentNo = studentNo;
	}
	public String getStudentName() {
		return StudentName;
	}
	public void setStudentName(String studentName) {
		StudentName = studentName;
	}
	public String getStudentDept() {
		return StudentDept;
	}
	public void setStudentDept(String studentDept) {
		StudentDept = studentDept;
	}
}
